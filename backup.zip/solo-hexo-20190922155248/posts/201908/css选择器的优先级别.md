title: css 选择器的优先级别
date: '2019-08-29 11:34:52'
updated: '2019-08-29 11:34:52'
tags: [CSS]
permalink: /articles/2019/08/29/1567049692195.html
---
!important > 行内style > id选择器 > class选择器
