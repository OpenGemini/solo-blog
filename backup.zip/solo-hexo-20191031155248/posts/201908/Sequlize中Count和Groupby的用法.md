title: Sequlize中Count和Groupby的用法
date: '2019-08-16 17:09:15'
updated: '2019-08-16 17:09:15'
tags: [node, sql]
permalink: /articles/2019/08/16/1565946555822.html
---
![](https://img.hacpai.com/bing/20181019.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

我们有一张预约的表 **user_appointment**,  结构如下:
![userappoint.png](https://img.hacpai.com/file/2019/08/userappoint-6c56f5c8.png)

当我们要统计各个医院的预约数量时，我们想到SQL语句大概是：
SELECT COUNT(DISTINCT hospital_id) FROM table;

在Sequelize中可以这样写：
```
const { count } =  await  app.model.UserAppointment.findOne({

where:  condition,

attributes: [[Sequelize.literal('COUNT(DISTINCT hospital_id)'), 'count']],

raw:  true,

});
```
假如我们要统计单日预约人数，并且根据创建时间排序的话，首先我们要先通过time预约时间和user_id两个字段来计算每天多少人进行预约。
SELECT DISTINCT user_id,time FROM user_appointment;

但是这样查询的结果只有user_id和time，查询结果如下：
user_id |          time
---------+------------------------
14 | 2019-08-19 00:00:00+08
3 | 2019-08-07 00:00:00+08
4 | 2019-08-12 08:00:00+08
14 | 2019-08-15 00:00:00+08

我们还要查询created_at 的字段，假如把SQL语句写错SELECT DISTINCT user_id,time,created_at FROM user_appointment, 那基本上会输出所有结果，因为distinct created_at，创建时间以微秒计算基本上都不一样。假如SQL语句写成SELECT created_at, DISTINCT user_id, time FROM user_appointment则会报错。

在mysql中我们可以使用group_contact，在postgresql中我们可以用distinct on。
```
datas  =  await  app.model.UserAppointment.findAll({

where:  condition,

order: [['time', 'DESC']],

attributes: [[Sequelize.literal(`DISTINCT on(user_id,time) created_at`), 'createdAt'], 'time'],

});
```
