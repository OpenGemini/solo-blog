title: postgre设置id自增
date: '2019-11-19 10:55:38'
updated: '2019-11-19 10:56:05'
tags: [postgre]
permalink: /articles/2019/11/19/1574132138243.html
---
修改id自增起始值为最大id值
```
select setval('your_table_id_seq',(select max(id) from 表名));

```
查看your_table_id_seq：
```
\d 表名
```
